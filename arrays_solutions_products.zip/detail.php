<?php // some code ?>
<!DOCTYPE HTML>
<html>
<head>
<title>Sweets Complete | Detail</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name ="description" content ="Sweets Complete">
<meta name="keywords" content="">
<link rel="stylesheet" href="css/main.css" type="text/css">
<link rel="shortcut icon" href="images/favicon.ico?v=2" type="image/x-icon" />
</head>
<body>
<div id="wrapper">
	<div id="maincontent">
		
	<div id="header">
		<div id="logo" class="left">
			<a href="index.php"><img src="images/logo.png" alt="SweetsComplete.Com"/></a>
		</div>
		<div class="right marT10">
			<b>
			<a href="login.html" >Login</a> |<a href="members.html" >Our Members</a> |<a href="cart.html" >Shopping Cart</a>
			</b>
			<br />
			Welcome Guest		</div>
		<ul class="topmenu">
		<li><a href="home.html">Home</a></li>
		<li><a href="about.html">About Us</a></li>
		<li><a href="products.html">Products</a></li>
		<li><a href="contact.html">Contact Us</a></li>
		</ul>
		<br>
		<div class="banner"><p></p></div>
		<br class="clear"/>
	</div> <!-- header -->
		
	<div class="content">	
	<br/>
	<div class="product-list">
		<h2>Product Details</h2>
		<br/>
		<div class="images">
			<a href="#">
				<img src="images/430_3150132.scale_20.JPG" alt=" Chocolate Angelfood Cupcakes" width="350" />
			</a>
		</div>
		<div class="details">
			<h3>SKU:  C3000</h3><br/>
			<h1 class="name"><b> Chocolate Angelfood Cupcakes</b></h1><br/>
			<p class="desc">Id ius detracto constituam, his possit platonem ne. Mel ad dolorum vivendum, vocent iisque salutandi in sit, nobis omnes eum ut. Nam simul tincidunt ei, in viris fabulas eos. Te per animal impetus, prompta platonem eloquentiam ea usu, efficiendi appellantur has in.
			</p>
			<br/>
			<p class="view"><b>Price: £0.30</b></p><br/>
			<form action="purchase.html" method="POST">
			<p class="view">
				<label>Qty:</label> <input type="text" value="1" name="qty" class="s0" size="2" />
				<input type="submit" name="purchase" value="Buy this item" class="button"/>
				<input type="hidden" name="price" value="0.30" />
				<input type="hidden" name="productID" value="3" />
			</p>
			</form>
		</div>
	</div><!-- product-list -->
<br class="clear-all"/>
</div><!-- content -->
	
	</div><!-- maincontent -->

	<div id="footer">
		<div class="footer">
			Copyright &copy; 2012 sweetscomplete.com. All rights reserved. <br/>
		<a href="home.html">Home</a> | <a href="about.html">About Us</a> | <a href="products.html">Products</a> | <a href="contact.html">Contact Us</a> 		<br />
			<span class="contact">Tel: +44-1234567890&nbsp;
			Fax: +44-1234567891&nbsp;
			Email:sales@sweetscomplete.com</span>
		</div>
	</div><!-- footer -->
	
</div><!-- wrapper -->

</body>
</html>

